import os
from pathlib import Path

files = [os.path.join(dp, f) for dp, dn, filenames in os.walk('default') for f in filenames]
print(files)

print(files)